<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'changelog' => '### Changelog mmxForms package installer for MODX3

```
1.0.1-pl (28.03.2024)
==============
- change builder
- change wrapper class
- wrapper class has been moved to the resolver

1.0.0-pl (26.03.2024)
==============
- initial commit
```',
    'license' => '### The MIT License

### Copyright (c) 2024 Vgrish <vgrish@gmail.com>

```
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```',
    'readme' => '# [mmx-forms](https://github.com/bezumkin/mmx-forms) package installer for MODX3

### Author: Vgrish <vgrish@gmail.com>

### Licence

```
The module code is licensed under the MIT License.
See the LICENSE file distributed with this work for additional
information regarding copyright ownership.

Withal, the license does not cover the assets, like built 
packages and other derivatives. Spreading such assets is prohibitted 
without prior written authorization.
```
',
    'requires' => 
    array (
      'php' => '>=8.1',
      'modx' => '>=3.0',
    ),
    'setup-options' => 'mmxforms-1.0.2-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => '9dd4c2da6e1b5074903727b07ca48632',
      'native_key' => '',
      'filename' => 'MODX/Revolution/modNamespace/5771506d3c25cb631b8a3d7fe5af4a7f.vehicle',
      'namespace' => 'mmxforms',
    ),
  ),
);